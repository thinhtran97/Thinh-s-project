"use strict";

// Lấy dữ liệu của mảng lưu vào Local Storage
let saveToStorage = function (key, value) {
  localStorage.setItem(key, JSON.stringify(value));
};
// Lấy dữ liêu Local Storage hiển thị thông tin lên web
let getFormStorage = function (key) {
  let value = JSON.parse(localStorage.getItem(key));
  return value;
};

// xóa dữ liệu của của mảng
let removeStorage = function (key) {
  localStorage.removeItem(key);
};
