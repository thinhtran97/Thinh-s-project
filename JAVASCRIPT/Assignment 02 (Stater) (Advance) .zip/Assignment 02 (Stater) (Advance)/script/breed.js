"use strict";

const submitBreed = document.getElementById("submit-btn");
const inputBreed = document.getElementById("input-breed");
const inputTypeBreed = document.getElementById("input-type");
const tableBreed = document.getElementById("tbody");

let breedArr = getFormStorage("breedArr") ? getFormStorage("breedArr") : [];
renderBreedTable(breedArr);

submitBreed.addEventListener("click", function () {
  let dataBreed = {
    breed: inputBreed.value,
    type: inputTypeBreed.value,
  };
  //validated Form Breeds:
  function validatedFormBreed() {
    for (let i = 0; i < breedArr.length; i++) {
      if (breedArr[i].breed == dataBreed["breed"]) {
        alert("Breed must unique!");
        return false;
      }
    }

    if (dataBreed.type === "Select Type") {
      alert("Please select Type");
      return false;
    } else if (dataBreed.breed === "") {
      alert("Please input Breed");
      return false;
    } else return true;
  }

  // validated Breed:
  const validatedBreed = validatedFormBreed();
  if (validatedBreed) {
    breedArr.push(dataBreed);

    //clear Input Form(breedArr)
    clearBreed();

    // Lấy dữ liệu của breedArr lưu vào Local Storage
    saveToStorage("breedArr", breedArr);

    // render Breeds Data
    renderBreedTable(breedArr);
  }
});

function renderBreedTable(Arr) {
  tableBreed.innerHTML = "";
  for (let i = 0; i < Arr.length; i++) {
    const rowBreed = document.createElement("tr");
    rowBreed.innerHTML = `
      <tr>
        <th scope="col">${i + 1}</th>
        <th scope="col">${Arr[i].breed}</th>
        <th scope="col">${Arr[i].type}</th>
        <th scope="col">
          <button
            type="button"
            class="btn btn-danger"
            onclick="deleteBreed(${i})"
          >
            Delete
          </button>
        </th>
      </tr>`;
    tableBreed.appendChild(rowBreed);
  }
}

// // Clear InputFormBreed:
function clearBreed() {
  inputBreed.value = "";
  inputTypeBreed.value = "Select Type";
}

//Delete Breed:
const deleteBreed = function (i) {
  // Confirm before deletePet
  if (confirm("Are you sure?")) {
    breedArr.splice(i, 1);
    renderBreedTable(breedArr);
    saveToStorage("breedArr", breedArr);
  }
};
