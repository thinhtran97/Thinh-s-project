"use strict";
const exportBtn = document.getElementById("export-btn");
const importBtn = document.getElementById("import-btn");
let petArr = getFormStorage("petArr");
console.log(petArr);
function saveDynamicDataToFile() {
  var data = localStorage.getItem("petArr");
  console.log(petArr);
  var blob = new Blob([data], { type: "text/plain;charset=utf-8" });
  saveAs(blob, "petArr.txt");
}
exportBtn.addEventListener("click", saveDynamicDataToFile);

function getFileContents() {
  var file = document.getElementById("input-file").files[0];
  if (file) {
    var reader = new FileReader();
    reader.readAsText(file, "UTF-8");
    reader.onload = function (evt) {
      var petArr = evt.target.result;
    };
  }
}
importBtn.addEventListener("submit", getFileContents);
