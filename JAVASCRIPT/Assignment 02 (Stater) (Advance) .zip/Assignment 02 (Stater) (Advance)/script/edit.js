"use strict";
const submitEdit = document.getElementById("submit-btn");
const tableBodyEl = document.getElementById("tbody");

let formEdit = document.getElementById("container-form");

let petArr = getFormStorage("petArr");
let breedArr = getFormStorage("breedArr");

const idInput = document.getElementById("input-id");
const nameInput = document.getElementById("input-name");
const ageInput = document.getElementById("input-age");
const typeInput = document.getElementById("input-type");
const weightInput = document.getElementById("input-weight");
const lengthInput = document.getElementById("input-length");
const colorInput = document.getElementById("input-color-1");
const breedInput = document.getElementById("input-breed");
const vaccinatedInput = document.getElementById("input-vaccinated");
const dewormedInput = document.getElementById("input-dewormed");
const sterilizedInput = document.getElementById("input-sterilized");
let dateEl = new Date();
let time =
  dateEl.getHours() +
  ":" +
  dateEl.getMinutes() +
  ":" +
  dateEl.getMilliseconds();
let day = dateEl.getDate();
let month = dateEl.getMonth() + 1;
let year = dateEl.getFullYear();

//render Table Data:
function renderTableData(Arr) {
  tableBodyEl.innerHTML = "";
  for (let i = 0; i < Arr.length; i++) {
    const row = document.createElement("tr");
    row.innerHTML = `<tr>
          <th scope="row">${Arr[i].id}</th>
          <td>${Arr[i].name}</td>
          <td>${Arr[i].age}</td>
          <td>${Arr[i].type}</td>
          <td>${Arr[i].weight} kg</td>
          <td>${Arr[i].length} cm</td>
          <td>${Arr[i].breed}</td>
          <td>
          <i class="bi bi-square-fill" style="color: ${Arr[i].color}"></i>
          </td>
          <td><i class="bi ${
            Arr[i].vaccinated ? "bi-check-circle-fill" : "bi-x-circle-fill"
          }"></i></td>
          <td><i class="bi ${
            Arr[i].dewormed ? "bi-check-circle-fill" : "bi-x-circle-fill"
          }"></i></td>
          <td><i class="bi ${
            Arr[i].sterilized ? "bi-check-circle-fill" : "bi-x-circle-fill"
          }"></i></td>
        
          <td>${Arr[i].date}</td>
          <td><button type="button" class="btn btn-danger" onclick="editPet(${i})" >Edit</button>
          </td>
          </tr>`;
    tableBodyEl.appendChild(row);
  }
}
renderTableData(petArr);

function editPet(i) {
  formEdit.classList.remove("hide");

  idInput.value = petArr[i].id;
  nameInput.value = petArr[i].name;
  ageInput.value = petArr[i].age;
  typeInput.value = petArr[i].type;
  weightInput.value = petArr[i].weight;
  lengthInput.value = petArr[i].length;
  colorInput.value = petArr[i].color;

  breedInput.value = petArr[i].breed;
  vaccinatedInput.checked = petArr[i].vaccinated;
  dewormedInput.checked = petArr[i].dewormed;
  sterilizedInput.checked = petArr[i].sterilized;
  renderBreed();
}

function renderBreed() {
  // let breedArr = getFormStorage("breedArr");
  console.log(breedArr);
  let inputType = document.getElementById("input-type").value;
  console.log(inputType);

  let breedFilter = breedArr.filter(function (item) {
    return item.type === inputType;
  });
  console.log(breedFilter);

  breedInput.innerHTML = "<option>Select Breed</option>";
  breedFilter.forEach((item) => {
    // for (let i = 0; i < breedFilter.length; i++) {
    const option = document.createElement("option");
    option.innerHTML = `
      <option>${item.breed}</option>
          `;
    breedInput.appendChild(option);
  });
}

typeInput.addEventListener("change", renderBreed);

function save() {
  console.log(petArr);
  let formEditData = {
    id: idInput.value,
    name: nameInput.value,
    age: parseInt(ageInput.value),
    type: typeInput.value,
    weight: parseInt(weightInput.value),
    length: parseInt(lengthInput.value),
    color: colorInput.value,
    breed: breedInput.value,
    vaccinated: vaccinatedInput.checked,
    dewormed: dewormedInput.checked,
    sterilized: sterilizedInput.checked,
    date: `${time} \n ${day}/${month}/${year}`,
  };
  console.log(formEditData);
  for (var i = 0; i < petArr.length; i++) {
    if (petArr[i].id === formEditData.id) {
      petArr.splice(i, 1, formEditData);
      saveToStorage("petArr", petArr);
      clearInput();
    }
  }
  renderTableData(petArr);
}
submitEdit.addEventListener("click", save);

const clearInput = function () {
  idInput.value = "";
  nameInput.value = "";
  ageInput.value = "";
  typeInput.value = "Seclect Type";
  lengthInput.value = "";
  colorInput.value = "#000000";
  breedInput.value = "Seclect Breed";
  weightInput.value = "";
  vaccinatedInput.checked = false;
  dewormedInput.checked = false;
  sterilizedInput.checked = false;
};
