"use strict";

const findBtn = document.getElementById("find-btn");
const tableBodyEl = document.getElementById("tbody");
let petArr = getFormStorage("petArr");
let breedArr = getFormStorage("breedArr");
let formEdit = document.getElementById("container-form");

const idInput = document.getElementById("input-id");
const nameInput = document.getElementById("input-name");
const ageInput = document.getElementById("input-age");
const typeInput = document.getElementById("input-type");
const weightInput = document.getElementById("input-weight");
const lengthInput = document.getElementById("input-length");
const colorInput = document.getElementById("input-color-1");
const breedInput = document.getElementById("input-breed");
const vaccinatedInput = document.getElementById("input-vaccinated");
const dewormedInput = document.getElementById("input-dewormed");
const sterilizedInput = document.getElementById("input-sterilized");
let dateEl = new Date();
let time =
  dateEl.getHours() +
  ":" +
  dateEl.getMinutes() +
  ":" +
  dateEl.getMilliseconds();
let day = dateEl.getDate();
let month = dateEl.getMonth() + 1;
let year = dateEl.getFullYear();

function renderTableData(Arr) {
  tableBodyEl.innerHTML = "";
  for (let i = 0; i < Arr.length; i++) {
    const row = document.createElement("tr");
    row.innerHTML = `<tr>
      <th scope="row">${Arr[i].id}</th>
      <td>${Arr[i].name}</td>
      <td>${Arr[i].age}</td>
      <td>${Arr[i].type}</td>
      <td>${Arr[i].weight} kg</td>
      <td>${Arr[i].length} cm</td>
      <td>${Arr[i].breed}</td>
      <td>
      <i class="bi bi-square-fill" style="color: ${Arr[i].color}"></i>
      </td>
      <td><i class="bi ${
        Arr[i].vaccinated ? "bi-check-circle-fill" : "bi-x-circle-fill"
      }"></i></td>
      <td><i class="bi ${
        Arr[i].dewormed ? "bi-check-circle-fill" : "bi-x-circle-fill"
      }"></i></td>
      <td><i class="bi ${
        Arr[i].sterilized ? "bi-check-circle-fill" : "bi-x-circle-fill"
      }"></i></td>
    
      <td>${Arr[i].date}</td>
      
      </tr>`;
    tableBodyEl.appendChild(row);
  }
}
renderTableData(petArr);

breedInput.innerHTML = "<option>Select Breed</option>";
breedArr.forEach((item) => {
  const option = document.createElement("option");
  option.innerHTML = `<option>${item.breed}</option>
    `;
  breedInput.appendChild(option);
});
// Tìm Pet theo Input(cách 1)
function findPet() {
  let data = {
    id: idInput.value,
    name: nameInput.value,
    type: typeInput.value,
    breed: breedInput.value,
    vaccinated: vaccinatedInput.checked,
    dewormed: dewormedInput.checked,
    sterilized: sterilizedInput.checked,
  };

  let result = petArr.filter(
    (cur) =>
      (data.id.length == 0 || cur.id.includes(data.id)) &&
      (data.name.length == 0 || cur.name.includes(data.name)) &&
      (data.type == "Select Type" || cur.type.includes(data.type)) &&
      (data.breed == "Select Breed" || cur.breed.includes(data.breed)) &&
      (data.vaccinated == false || cur.vaccinated === true) &&
      (data.dewormed == false || cur.dewormed === true) &&
      (data.sterilized == false || cur.sterilized === true)
  );
  //);
  console.log(result);
  // saveToStorage("result", result);
  renderTableData(result);
}

findBtn.addEventListener("click", findPet);
