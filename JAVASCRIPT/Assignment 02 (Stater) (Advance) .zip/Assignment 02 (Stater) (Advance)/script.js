'use strict';

const submitBtn = document.getElementById("submit-btn");
const showHealthyPet = document.getElementById("healthy-btn");
const calculateBMI = document.getElementById("bmi-btn");

const idInput = document.getElementById("input-id");
const nameInput = document.getElementById("input-name");
const ageInput = document.getElementById("input-age");
const typeInput = document.getElementById("input-type");
const weightInput = document.getElementById("input-weight");
const lengthInput = document.getElementById("input-length");
const colorInput = document.getElementById("input-color-1");
const breedInput = document.getElementById("input-breed");
const vaccinatedInput = document.getElementById("input-vaccinated");
const dewormedInput = document.getElementById("input-dewormed");
const sterilizedInput = document.getElementById("input-sterilized");
const tableBodyEl = document.getElementById("tbody");
let dateEl = new Date();
let time =
  dateEl.getHours() +
  ":" +
  dateEl.getMinutes() +
  ":" +
  dateEl.getMilliseconds();
let day = dateEl.getDate();
let month = dateEl.getMonth() + 1;
let year = dateEl.getFullYear();

let petArr = getFormStorage("petArr") ? getFormStorage("petArr") : [];
renderTableData(petArr);
//let breedArr = getFormStorage("breedArr");

//let healthyCheck = false;
// let healthyPetArr = [];

submitBtn.addEventListener("click", function (e) {
  //Data Form:
  const data = {
    id: idInput.value,
    name: nameInput.value,
    age: parseInt(ageInput.value),
    type: typeInput.value,
    weight: parseInt(weightInput.value),
    length: parseInt(lengthInput.value),
    color: colorInput.value,
    breed: breedInput.value,
    vaccinated: vaccinatedInput.checked,
    dewormed: dewormedInput.checked,
    sterilized: sterilizedInput.checked,
    date: `${time} \n ${day}/${month}/${year}`,
  };

  //validatedForm:
  function validatedForm() {
    for (let i = 0; i < petArr.length; i++) {
      if (petArr[i].id == data["id"]) {
        alert("ID must unique!");
        return false;
      }
    }

    if (!data.id) {
      alert("Please input ID");
      return false;
    } else if (!data.name) {
      alert("Please input Name");
      return false;
    } else if (isNaN(data.age) || data.age < 1 || data.age > 15) {
      alert("Age must be between 1 and 15!");
      return false;
    } else if (data.type == "Select Type") {
      alert("Please select Type");
      return false;
    } else if (isNaN(data.weight) || data.weight < 1 || data.weight > 15) {
      alert("Weight must be between 1 and 15!");
      return false;
    } else if (isNaN(data.length) || data.length < 1 || data.length > 100) {
      alert("Length must be between 1 and 100!");
      return false;
    } else if (data.breed == "Select Breed") {
      alert("Please select Breed");
      return false;
    } else return true;
  }

  // validated:
  const validated = validatedForm();
  if (validated) {
    petArr.push(data);
    // render Table Data
    clearInput();
    renderTableData(petArr);
    saveToStorage("petArr", petArr);
  }
  console.log(petArr);
});

//render Table Data:
function renderTableData(Arr) {
  tableBodyEl.innerHTML = "";
  for (let i = 0; i < Arr.length; i++) {
    const row = document.createElement("tr");
    row.innerHTML = `<tr>
        <th scope="row">${Arr[i].id}</th>
        <td>${Arr[i].name}</td>
        <td>${Arr[i].age}</td>
        <td>${Arr[i].type}</td>
        <td>${Arr[i].weight} kg</td>
        <td>${Arr[i].length} cm</td>
        <td>${Arr[i].breed}</td>
        <td>
        <i class="bi bi-square-fill" style="color: ${Arr[i].color}"></i>
        </td>
        <td><i class="bi ${
          Arr[i].vaccinated ? "bi-check-circle-fill" : "bi-x-circle-fill"
        }"></i></td>
        <td><i class="bi ${
          Arr[i].dewormed ? "bi-check-circle-fill" : "bi-x-circle-fill"
        }"></i></td>
        <td><i class="bi ${
          Arr[i].sterilized ? "bi-check-circle-fill" : "bi-x-circle-fill"
        }"></i></td>
      
        <td>${Arr[i].date}</td>
        <td><button type="button" class="btn btn-danger" onclick="deletePet(${i})" >Delete</button>
        </td>
        </tr>`;
    tableBodyEl.appendChild(row);
  }
}

// Clear InputForm:
const clearInput = function () {
  idInput.value = "";
  nameInput.value = "";
  ageInput.value = "";
  typeInput.value = "Seclect Type";
  lengthInput.value = "";
  colorInput.value = "#000000";
  breedInput.value = "Seclect Breed";
  weightInput.value = "";
  vaccinatedInput.checked = false;
  dewormedInput.checked = false;
  sterilizedInput.checked = false;
};

//Delete Pet:
const deletePet = function (i) {
  // Confirm before deletePet
  if (confirm("Are you sure?")) {
    petArr.splice(i, 1);
    renderTableData(petArr);
    saveToStorage("petArr", petArr);
  }
};

//Show Healthy Pet

// showHealthyPet.addEventListener("click", function () {
//   if (showHealthyPet.textContent === "Show Healthy Pet") {
//     healthyPetArr = [];
//     for (let i = 0; i < petArr.length; i++) {
//       if (
//         petArr[i].vaccinated === true &&
//         petArr[i].dewormed === true &&
//         petArr[i].sterilized === true
//       ) {
//         healthyPetArr.push(petArr[i]);
//       }
//       console.log(healthyPetArr);
//     }
//     renderTableData(healthyPetArr);
//     showHealthyPet.textContent = "Show All Pet";
//   } else {
//     showHealthyPet.textContent = "Show Healthy Pet";
//     renderTableData(petArr);
//   }
//   // showAllPet.textContent = "Show Healthy Pet"
//   //   ? (showAllPet.textContent = "Show All Pet")
//   //   : (showAllPet.textContent = "Show Healthy Pet");
// });
showHealthyPet.addEventListener("click", function () {
  if (showHealthyPet.textContent.trim() === "Show Healthy Pet") {
    const healthyPets = petArr.filter(
      (item) => item.vaccinated && item.sterilized && item.dewormed
    );
    //debugger;
    renderTableData(healthyPets);
    showHealthyPet.textContent = "Show All Pet";
  } else {
    showHealthyPet.textContent = "Show Healthy Pet";
    renderTableData(petArr);
  }
});
//Calculate  BMI:

// // const dogBMI = (weight * 703) / length ** 2;
// // const catBMI = (weight * 886) / length ** 2;
// calculateBMI.addEventListener("click", function () {
//   for (let i = 0; i < petArr.length; i++) {
//     petArr[i].bmi =
//       petArr[i].type === "Dog"
//         ? ((petArr[i].weight * 7.03) / petArr[i].length ** 2).toFixed(2)
//         : ((petArr[i].weight * 8.86) / petArr[i].length ** 2).toFixed(2);

//     renderTableData(petArr);
//   }
// });

//Bổ sung Animation cho Sidebar
const nav = document.getElementById("sidebar");
nav.addEventListener("click", function () {
  nav.classList.toggle("active");
});
const content = document.getElementById("content");
content.addEventListener("click", function () {
  nav.classList.add("active");
});

// Hiển thị Breed trong màn hình quản lý thú cưng

function renderBreed() {
  let breedArr = getFormStorage("breedArr");
  console.log(breedArr);
  let inputType = document.getElementById("input-type").value;
  console.log(inputType);

  let breedFilter = breedArr.filter(function (item) {
    return item.type === inputType;
  });
  console.log(breedFilter);

  breedInput.innerHTML = "<option>Select Breed</option>";
  breedFilter.forEach((item) => {
    // for (let i = 0; i < breedFilter.length; i++) {
    const option = document.createElement("option");
    option.innerHTML = `<option>${item.breed}</option>
        `;
    breedInput.appendChild(option);
  });
}

typeInput.addEventListener("change", renderBreed);
