'use strict';
const articleEl = document.getElementById('news-container');
const inputQuery = document.getElementById('input-query');
const btnSearch = document.getElementById('btn-submit');
const btnPrev = document.getElementById('btn-prev');
const btnNext = document.getElementById('btn-next');
const pageNum = document.getElementById('page-num');
const navPageNum = document.getElementById('nav-page-num');
let totalResults;
let newsPerPage;

// get newsPerPage from local storage
if (
  getFromStorage('newsPerPage').length == 0 ||
  getFromStorage('newsPerPage') == ''
)
  newsPerPage = 5;
else newsPerPage = getFromStorage('newsPerPage');

// get data from API
const search = async function (key, apiKey) {
  hideBtn();
  try {
    const response = await fetch(
      `https://newsapi.org/v2/everything?q=${key}&apiKey=${apiKey}&pageSize=${newsPerPage}&page=${pageNum.textContent}`
    );
    if (!response.ok) throw new Error(`Problem with error ${response.status}`);
    const res = await response.json();
    console.log(res);
    let data = res.articles;
    if (res.totalResults >= 100) totalResults = 100;
    else totalResults = res.totalResults;
    console.log(totalResults);
    renderArticle(data);
  } catch (err) {
    articleEl.innerHTML = '';
    let divError = document.createElement('div');
    divError.innerHTML = `<h3>Cannot connect to server. Please try again!</h3>
    <h4 style='margin-left: 150px'>${err.message}</h4>`;
    divError.style.marginLeft = '200px';
    divError.style.marginTop = '100px';
    articleEl.appendChild(divError);
    navPageNum.hidden = true;
  }
};

// show article
function renderArticle(data) {
  navPageNum.hidden = false;
  articleEl.innerHTML = '';
  for (let i = 0; i < data.length; i++) {
    let article = document.createElement('div');
    article.innerHTML = `<div class='row' style='border: solid 2px #e4e4e2; margin-bottom:1%'>
    <div class='col-6 col-lg-4'><img src='${data[i].urlToImage}' style='width: 100% ;margin-left:-15px'></img></div>
    <div class ='col-8 col-lg-8' style='padding-top: 1%; margin-left: -2%'>
      <h6 style='font-weight: bold; color: black'>${data[i].title}</h6>
      <p>${data[i].description}</p>
      <button class='btn btn-primary'><a href='${data[i].url}' style='color:white'>View</a></button>
    </div>
    </div>
    `;
    articleEl.appendChild(article);
  }
}

// hide button
function hideBtn() {
  if (pageNum.textContent === '1') btnPrev.hidden = true;
  else btnPrev.hidden = false;
  if (pageNum.textContent * newsPerPage >= totalResults) btnNext.hidden = true;
  else btnNext.hidden = false;
}

// hide nav page number on load
navPageNum.hidden = true;

// event click button Search
btnSearch.addEventListener('click', () => {
  if (inputQuery.value === '') alert('Please input for keywords');
  else search(inputQuery.value, 'd199428d555a48df947289f1239cd948');
});

// event click button next
btnNext.addEventListener('click', () => {
  pageNum.textContent++;
  search(inputQuery.value, 'd199428d555a48df947289f1239cd948');
});

// event click button previous
btnPrev.addEventListener('click', () => {
  pageNum.textContent--;
  search(inputQuery.value, 'd199428d555a48df947289f1239cd948');
});
