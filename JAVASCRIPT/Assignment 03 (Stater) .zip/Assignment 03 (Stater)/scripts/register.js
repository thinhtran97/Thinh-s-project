'use strict';

const firstNameEl = document.getElementById('input-firstname');
const lastNameEl = document.getElementById('input-lastname');
const userNameEl = document.getElementById('input-username');
const passwordEl = document.getElementById('input-password');
const confirmPasswordEl = document.getElementById('input-password-confirm');
const btnSubmitEl = document.getElementById('btn-submit');
let userArr = getFromStorage('list-user') || [];
firstNameEl.type = 'name';
// reset form
function init() {
  firstNameEl.value = '';
  lastNameEl.value = '';
  userNameEl.value = '';
  passwordEl.value = '';
  confirmPasswordEl.value = '';
}

// check unique username
function checkId() {
  for (let i = 0; i < userArr.length; i++) {
    if (userNameEl.value == userArr[i].username) return true;
  }
}

//validate input form
function validate() {
  if (checkId()) alert('Username must unique!');
  else if (firstNameEl.value.trim() == '' || /[0-9]/.test(firstNameEl.value))
    alert('First name cannot blank and does not includes number!');
  else if (lastNameEl.value.trim() == '' || /[0-9]/.test(lastNameEl.value))
    alert('Last name cannot blank and does not includes number!');
  else if (userNameEl.value.trim() == '') alert('Please input for username');
  else if (passwordEl.value.length < 8)
    alert('Password must be more than 8 characters');
  else if (confirmPasswordEl.value !== passwordEl.value)
    alert('The confirmation password is not the same as the entered password');
  else {
    let user = new User(
      firstNameEl.value,
      lastNameEl.value,
      userNameEl.value,
      passwordEl.value
    );
    init();
    userArr.push(user);
    saveToStorage('list-user', userArr);
    window.location.href = '../pages/login.html';
  }
}

// event click button register
btnSubmitEl.addEventListener('click', validate);
