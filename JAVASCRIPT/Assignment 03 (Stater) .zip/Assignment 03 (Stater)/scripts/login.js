'use strict';

const userNameEl = document.getElementById('input-username');
const passwordEl = document.getElementById('input-password');
const btnLogin = document.getElementById('btn-submit');

let userArr = getFromStorage('list-user') || [];

// validate login
function checkLogin() {
  if (userNameEl.value.trim() == '') alert('Please input for username!');
  else if (passwordEl.value.trim() == '') alert('Please input for password!');
  if (userNameEl.value.trim() !== '' && passwordEl.value.trim() !== '') {
    const checkUser = userArr.find(user => user.username == userNameEl.value);
    if (checkUser === undefined) alert('Username not register!');
    else if (checkUser.password !== passwordEl.value)
      alert('Wrong password. Please try again!');
    else {
      window.location.href = '../index.html';
      saveToStorage('currentUser', checkUser);
    }
  }
}

// event click button login
btnLogin.addEventListener('click', checkLogin);
