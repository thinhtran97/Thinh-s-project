"use strict";

const currentUser = getFromStorage("currentUser") || [];
const todoArr = getFromStorage("TodoList") || [];
const inputTaskEl = document.getElementById("input-task");
const btnAdd = document.getElementById("btn-add");
const todoListEl = document.getElementById("todo-list");

let isDone;

renderTodoList();

// event click button add
btnAdd.addEventListener("click", () => {
  if (currentUser.length == 0) {
    alert("Please login to add todo!");
  } else if (inputTaskEl.value == "") {
    alert("Please input for todo!");
  } else {
    let task = new TodoList(inputTaskEl.value, currentUser.username, isDone);
    console.log(task);
    inputTaskEl.value = "";
    todoArr.push(task);
    saveToStorage("TodoList", todoArr);
    renderTodoList();
  }
});

// show todo list
function renderTodoList() {
  todoListEl.innerHTML = "";
  for (let i = 0; i < todoArr.length; i++) {
    if (todoArr[i].owner === currentUser.username) {
      let todoList = document.createElement("li");
      todoList.className = `${todoArr[i].isDone == true ? "checked" : ""}`;
      todoList.innerHTML = `${todoArr[i].task}<span class='close' onclick='deleteTask(${i})'>x</span>`;
      todoListEl.appendChild(todoList);
      todoList.addEventListener("click", () => {
        todoList.classList.toggle("checked");
        todoArr[i].isDone = todoArr[i].isDone ? false : true;
        saveToStorage("TodoList", todoArr);
      });
    }
  }
}

// delete
function deleteTask(task) {
  event.stopPropagation();
  todoArr.splice(task, 1);
  saveToStorage("TodoList", todoArr);
  renderTodoList();
}
