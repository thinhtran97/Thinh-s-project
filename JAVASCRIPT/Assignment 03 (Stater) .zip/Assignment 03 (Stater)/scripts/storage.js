'use strict';

// save data to local storage
function saveToStorage(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

// get data from local storage
function getFromStorage(key) {
  let keyContent = localStorage.getItem(key)
    ? JSON.parse(localStorage.getItem(key))
    : [];
  return keyContent;
}
