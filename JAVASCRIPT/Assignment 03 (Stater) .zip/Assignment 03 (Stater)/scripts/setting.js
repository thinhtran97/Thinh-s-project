'use strict';

const inputPageSize = document.getElementById('input-page-size');
const inputCategory = document.getElementById('input-category');
const btnSaveSetting = document.getElementById('btn-submit');

// event button save
btnSaveSetting.addEventListener('click', () => {
  // validate input
  if (inputPageSize.value !== '') {
    if (inputPageSize.value % 1 == 0 && inputPageSize.value > 0) {
      saveToStorage('newsPerPage', inputPageSize.value);
      saveToStorage('category', inputCategory.value);
      alert('Setting success!');
    } else
      alert(
        'News Per Page must be integer and greater than 0. Please try again!'
      );
  } else {
    alert('Setting success!');
    saveToStorage('category', inputCategory.value);
  }
});
