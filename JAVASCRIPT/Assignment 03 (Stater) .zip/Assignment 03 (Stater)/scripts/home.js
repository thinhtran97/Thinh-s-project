'use strict';

const loginModalEl = document.getElementById('login-modal');
const logoutEl = document.getElementById('main-content');
const message = document.getElementById('welcome-message');
const btnLogoutEl = document.getElementById('btn-logout');
const currentUser = getFromStorage('currentUser') || [];

if (currentUser.length !== 0) {
  loginModalEl.hidden = true;
  message.innerHTML = `Welcome ${
    currentUser.firstName.charAt(0).toUpperCase() +
    currentUser.firstName.slice(1)
  }`;
} else {
  logoutEl.hidden = true;
}

btnLogoutEl.addEventListener('click', function () {
  localStorage.removeItem('currentUser');
  window.location.href = './pages/login.html';
});
