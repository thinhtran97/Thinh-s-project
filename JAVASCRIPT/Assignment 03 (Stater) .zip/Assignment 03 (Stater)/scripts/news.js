'use strict';

const articleEl = document.getElementById('news-container');
const navPageNum = document.getElementById('nav-page-num');
const pageNum = document.getElementById('page-num');
const btnPrev = document.getElementById('btn-prev');
const btnNext = document.getElementById('btn-next');
let category = getFromStorage('category') || 'General';
let newsPerPage;
let totalResults;

// set news per page
if (
  getFromStorage('newsPerPage').length == 0 ||
  getFromStorage('newsPerPage') == ''
)
  newsPerPage = 5;
else newsPerPage = getFromStorage('newsPerPage');

// show article
function renderArticle(data) {
  articleEl.innerHTML = '';
  for (let i = 0; i < data.length; i++) {
    let article = document.createElement('div');
    article.innerHTML = `<div class='row' style='border: solid 2px #e4e4e2; margin-bottom:1%'>
    <div class='col-6 col-lg-4'><img src='${data[i].urlToImage}' style='width: 100% ;margin-left:-15px'></img></div>
    <div class ='col-8 col-lg-8' style='padding-top: 1%; margin-left: -2%'>
      <h6 style='font-weight: bold; color: black'>${data[i].title}</h6>
      <p>${data[i].description}</p>
      <button class='btn btn-primary'><a href='${data[i].url}' style='color:white'>View</a></button>
    </div>
    </div>
    `;
    articleEl.appendChild(article);
  }
}

// get data from API
const news = async function (country, category, apiKey, pageSize, pageNum) {
  hideBtn();
  try {
    const response = await fetch(
      `https://newsapi.org/v2/top-headlines?country=${country}&category=${category}&apiKey=${apiKey}&pageSize=${pageSize}&page=${pageNum}`
    );
    if (!response.ok) throw new Error(`Problem with error ${response.status}`);
    const res = await response.json();
    let data = res.articles;
    console.log(data);
    if (res.totalResults >= 100) totalResults = 100;
    else totalResults = res.totalResults;
    renderArticle(data);
  } catch (err) {
    articleEl.innerHTML = '';
    let divError = document.createElement('div');
    divError.innerHTML = `<h3>Cannot connect to server. Please try again!</h3>
    <h4 style='margin-left: 150px'>${err.message}</h4>`;
    divError.style.marginLeft = '200px';
    divError.style.marginTop = '100px';
    articleEl.appendChild(divError);
    navPageNum.hidden = true;
  }
};

news(
  'us',
  category,
  'd199428d555a48df947289f1239cd948',
  newsPerPage,
  pageNum.textContent
);

// hide button
function hideBtn() {
  if (pageNum.textContent === '1') btnPrev.hidden = true;
  else btnPrev.hidden = false;
  if (pageNum.textContent * newsPerPage >= totalResults) btnNext.hidden = true;
  else btnNext.hidden = false;
}

// button next
btnNext.addEventListener('click', function () {
  pageNum.textContent++;
  news(
    'us',
    category,
    'd199428d555a48df947289f1239cd948',
    newsPerPage,
    pageNum.textContent
  );
});

// button previous
btnPrev.addEventListener('click', function () {
  pageNum.textContent--;
  news(
    'us',
    category,
    'd199428d555a48df947289f1239cd948',
    newsPerPage,
    pageNum.textContent
  );
});
