'use strict';

// create constructor
class User {
  constructor(firstName, lastName, username, password) {
    (this.firstName = firstName),
      (this.lastName = lastName),
      (this.username = username),
      (this.password = password);
  }
}

class TodoList {
  constructor(task, owner, isDone) {
    (this.task = task), (this.owner = owner), (this.isDone = isDone);
  }
}
